
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score

# Load Dataset
df = pd.read_csv(r"D:\Downloads\diabetes.csv")

print("Shape:")
print(df.shape)

print("\nColumns:")
print(df.columns)

print("\nInformation:")
print(df.info())

print("\nStatistics:")
print(df.describe())

# Features and Target
X = df.drop("Outcome", axis=1)
y = df["Outcome"]

print("\nFeatures:")
print(X.head())

print("\nTarget:")
print(y.head())

# Split Dataset
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42
)

print("\nTraining Data Shape:")
print(X_train.shape)

print("\nTesting Data Shape:")
print(X_test.shape)

# Random Forest
rf = RandomForestClassifier(random_state=42)
rf.fit(X_train, y_train)
pred_rf = rf.predict(X_test)
rf_acc = accuracy_score(y_test, pred_rf)

print("\nRandom Forest Accuracy:", rf_acc)

# Logistic Regression
lr = LogisticRegression(max_iter=1000)
lr.fit(X_train, y_train)
pred_lr = lr.predict(X_test)
lr_acc = accuracy_score(y_test, pred_lr)

print("Logistic Regression Accuracy:", lr_acc)

# Decision Tree
dt = DecisionTreeClassifier(random_state=42)
dt.fit(X_train, y_train)
pred_dt = dt.predict(X_test)
dt_acc = accuracy_score(y_test, pred_dt)

print("Decision Tree Accuracy:", dt_acc)

# User Prediction
print("\n--- Diabetes Prediction ---")
preg = float(input("Enter Pregnancies: "))
glu = float(input("Enter Glucose: "))
bp = float(input("Enter Blood Pressure: "))
skin = float(input("Enter Skin Thickness: "))
insulin = float(input("Enter Insulin: "))
bmi = float(input("Enter BMI: "))
dpf = float(input("Enter Diabetes Pedigree Function: "))
age = float(input("Enter Age: "))

sample = [[preg, glu, bp, skin, insulin, bmi, dpf, age]]
result = lr.predict(sample)

if result[0] == 1:
    print("\nPatient is likely Diabetic")
else:
    print("\nPatient is likely Non-Diabetic")

# Accuracy Comparison Graph
algorithms = ["Logistic Regression", "Decision Tree", "Random Forest"]
accuracies = [lr_acc * 100, dt_acc * 100, rf_acc * 100]

plt.figure(figsize=(6, 4))
plt.bar(algorithms, accuracies)
plt.title("Accuracy Comparison")
plt.ylabel("Accuracy (%)")
plt.show()

# Diabetes Distribution Graph
plt.figure(figsize=(5, 4))
df["Outcome"].value_counts().plot(kind="bar")
plt.title("Diabetes Distribution")
plt.xlabel("Outcome")
plt.ylabel("Count")
plt.show()
